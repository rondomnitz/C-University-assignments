#include <stdio.h>
# define TRUE 1
# define FALSE 0
# define N 9
typedef int adjmat [N][N];
